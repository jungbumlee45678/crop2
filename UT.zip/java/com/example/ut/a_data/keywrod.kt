package com.example.ut.a_data

data class keywrod(
    val keyword:String
)

data class keywrod_input(
    val keyword:String,
    val userid:String,
    val input:Int
)
