package com.example.ut.a_data

data class login_member_data(
    val userid:String,
    val userpw:String,
    )