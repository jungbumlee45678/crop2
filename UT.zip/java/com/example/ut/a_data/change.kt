package com.example.ut.a_data

data class change(
    val userid:String,
    val userpw:String,
    val change:String
)
