package com.example.ut.a_data

data class info(
    val userid:String,
    val username:String,
    val address:String,
    val email:String
)
