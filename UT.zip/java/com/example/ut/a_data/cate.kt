package com.example.ut.a_data

data class cate(
    val category:MutableList<String>,
    val userid:String
)
