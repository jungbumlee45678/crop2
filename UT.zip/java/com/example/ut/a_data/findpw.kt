package com.example.ut.a_data

data class findpw(
    val userid:String,
    val username:String,
    val email:String
)
