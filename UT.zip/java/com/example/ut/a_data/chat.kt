package com.example.ut.a_data

data class chat(
    val boardid:Int,
    val userid:String
)

data class chat_num(
    val num:Int
)
