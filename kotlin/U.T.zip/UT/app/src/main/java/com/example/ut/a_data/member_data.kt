package com.example.ut.a_data

data class member_data(
    val userid:String,
    val userpw:String,
    val username:String,
    val email:String,
    val address:String,
    val latitude:Double,
    val longitude:Double
)

data class userid(
    val userid:String
)
