package com.example.ut.a_data

data class location(
    val latitude: Double,
    val longitude: Double
)
