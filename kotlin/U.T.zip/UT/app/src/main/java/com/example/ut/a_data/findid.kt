package com.example.ut.a_data

data class findid(
    val username:String,
    val email:String
)
